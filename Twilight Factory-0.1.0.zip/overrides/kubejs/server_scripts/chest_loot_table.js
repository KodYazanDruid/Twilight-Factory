onEvent('chest.loot_tables', event => {
    /*
    *   Twilight Forest, Dungeon Crawl, Dungeons Arise
    *   loot_table'larına bazı enigmatic legacy ve create (belki ae2) eşyaları eklenecek.
    *
    *
    *
    */
})