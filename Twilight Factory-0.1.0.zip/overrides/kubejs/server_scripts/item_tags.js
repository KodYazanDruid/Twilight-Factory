onEvent('tags.items', event => {
    event.add('forge:mazestone', [
    'twilightforest:mazestone',
    'twilightforest:mazestone_brick',
    'twilightforest:cracked_mazestone',
    'twilightforest:mossy_mazestone',
    'twilightforest:decorative_mazestone',
    'twilightforest:cut_mazestone',
    'twilightforest:mazestone_border',
    'twilightforest:mazestone_mosaic'
    ])
})