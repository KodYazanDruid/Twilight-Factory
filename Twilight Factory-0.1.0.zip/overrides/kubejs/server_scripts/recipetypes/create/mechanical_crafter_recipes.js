onEvent('recipes', event => {
    event.recipes.createMechanicalCrafting('kubejs:crude_controller', [
        'SASAS',
        'AFTFA',
        'STCTS',
        'AFTFA',
        'SASAS'
        ], {
            S: 'ae2:smooth_sky_stone_block',
            A: 'twilightforest:aurora_block',
            F: 'twilightforest:fiery_ingot',
            T: 'twilightforest:torchberries',
            C: 'ae2:engineering_processor'
    })
})
