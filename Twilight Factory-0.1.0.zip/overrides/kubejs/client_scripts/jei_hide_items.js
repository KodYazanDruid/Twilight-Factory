onEvent('jei.hide.items', event => {
    event.hide('kubejs:incomplete_refined_fluix_mechanism')
    event.hide('chunkloaders:single_chunk_loader')
})