onEvent('item.tooltip', event => {
    event.add('bigreactors:yellorite_ore', 'Cannot be smelted. Not even with power of the blood of the Hydra.')
})