onEvent('fluid.registry', event =>{
    event.create('fiery_fluid')
        .displayName('Fiery Fluid')
        .thickTexture(0xFF0000)
        .noBucket
        .noBlock
        //.stillTexture('')
        //.flowingTexture('')
})