onEvent('block.registry', event => {
    event.create('crude_controller').material('metal').hardness(2).displayName('Crude Controller').tagBlock('minecraft:mineable/pickaxe')
})