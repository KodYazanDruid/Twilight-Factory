onEvent('item.registry', event => {
	event.create('raw_uranium').displayName('Raw Uranium')
	event.create('ironwood_nugget').displayName('Ironwood Nugget')
	event.create('crushed_ironwood').displayName('Crushed Ironwood')
	event.create('refined_fluix_mechanism').displayName('Refined Fluix Mechanism')
	event.create('incomplete_refined_fluix_mechanism').displayName('Incomplete Refined Fluix Mechanism')
	event.create('crushed_etherium_ore').displayName('Crushed Etherium Ore')
})


